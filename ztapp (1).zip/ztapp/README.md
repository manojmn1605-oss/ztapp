# Zero Trust Demo App

Flask app protected by Cloudflare Access + Tunnel. Verifies the Access JWT on every request.

## Local test (no Cloudflare needed)
    python3 -m venv venv && source venv/bin/activate
    pip install -r requirements.txt
    DEV_MODE=1 python app.py          # then: curl http://127.0.0.1:5000/whoami
DEV_MODE skips JWT checks. Never enable it on the VM.

## Deploy on the VM
1. Copy this folder to ~/ztapp (VM has no inbound ports; use SSM / IAP / console).
2. `bash setup.sh <TEAM_NAME> <APP_AUD_TAG>`
3. Install cloudflared, create tunnel, public hostname `app.yourdomain.com` -> `http://localhost:5000`.
4. Create the Access application + Allow policy (emails / Google login).

Team name = `<team>.cloudflareaccess.com`. AUD tag = Access app > Overview.

## Endpoints
- `/`        HTML page showing verified identity
- `/whoami`  JSON identity

## Quick tests
- No token: `curl http://127.0.0.1:5000/` -> 403
- Spoofed header: `curl -H "Cf-Access-Authenticated-User-Email: a@b.c" https://app.yourdomain.com` -> blocked by Access
