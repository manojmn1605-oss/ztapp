"""Zero Trust demo app: Flask behind Cloudflare Access + Tunnel.

The app never trusts the network or the proxy blindly. Every request must carry
a signed Cloudflare Access JWT, which is verified (signature, audience, issuer,
expiry) before any page is served.
"""
import logging
import os
from datetime import datetime, timezone
from functools import wraps

import jwt
from flask import Flask, abort, g, jsonify, render_template_string, request
from jwt import PyJWKClient

TEAM = os.environ.get("CF_TEAM_NAME", "")          # e.g. "myteam"
AUD = os.environ.get("CF_ACCESS_AUD", "")          # Application AUD tag
DEV_MODE = os.environ.get("DEV_MODE") == "1"       # local testing ONLY

if not DEV_MODE and not (TEAM and AUD):
    raise RuntimeError("Set CF_TEAM_NAME and CF_ACCESS_AUD (or DEV_MODE=1 locally).")

ISSUER = f"https://{TEAM}.cloudflareaccess.com"
CERTS_URL = f"{ISSUER}/cdn-cgi/access/certs"
jwks_client = None if DEV_MODE else PyJWKClient(CERTS_URL, cache_keys=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("ztapp")
app = Flask(__name__)

PAGE = """
<!doctype html>
<title>Zero Trust Demo</title>
<style>
  body{font-family:system-ui,Arial,sans-serif;background:#10202b;color:#eaf2f0;
       display:grid;place-items:center;min-height:100vh;margin:0}
  .card{background:#1b3a4b;padding:2rem 2.5rem;border-radius:14px;max-width:520px}
  h1{margin:0 0 .5rem;font-size:1.6rem} .ok{color:#17a398;font-weight:700}
  td{padding:.25rem .75rem .25rem 0} td:first-child{color:#9fb3bf}
</style>
<div class="card">
  <h1>Hello {{ email }}</h1>
  <p class="ok">&#10003; Identity verified: you passed zero trust.</p>
  <table>
    <tr><td>Identity provider</td><td>{{ idp }}</td></tr>
    <tr><td>Token issued</td><td>{{ iat }}</td></tr>
    <tr><td>Token expires</td><td>{{ exp }}</td></tr>
    <tr><td>Country</td><td>{{ country }}</td></tr>
  </table>
</div>
"""


def _ts(value):
    return datetime.fromtimestamp(value, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def verify_token(token):
    """Return verified claims or None."""
    if DEV_MODE:
        now = int(datetime.now(tz=timezone.utc).timestamp())
        return {"email": "dev@localhost", "iat": now, "exp": now + 3600,
                "identity_nonce": "dev", "country": "local"}
    try:
        key = jwks_client.get_signing_key_from_jwt(token).key
        return jwt.decode(token, key, algorithms=["RS256"], audience=AUD, issuer=ISSUER)
    except jwt.PyJWTError as exc:
        log.warning("JWT rejected: %s", exc)
        return None


def require_access(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        token = request.headers.get("Cf-Access-Jwt-Assertion")
        if not token and not DEV_MODE:
            log.warning("Denied: no Access JWT from %s", request.remote_addr)
            abort(403)
        claims = verify_token(token)
        if not claims:
            abort(403)
        g.claims = claims
        return view(*args, **kwargs)
    return wrapper


@app.route("/")
@require_access
def home():
    c = g.claims
    log.info("Allowed: %s", c.get("email"))
    return render_template_string(
        PAGE,
        email=c.get("email", "unknown"),
        idp=c.get("idp", {}).get("type", "n/a") if isinstance(c.get("idp"), dict) else "n/a",
        iat=_ts(c["iat"]), exp=_ts(c["exp"]), country=c.get("country", "n/a"),
    )


@app.route("/whoami")
@require_access
def whoami():
    c = g.claims
    return jsonify(email=c.get("email"), issued=_ts(c["iat"]), expires=_ts(c["exp"]))


@app.errorhandler(403)
def forbidden(_):
    return "403 Forbidden: valid Cloudflare Access identity required.\n", 403


if __name__ == "__main__":
    # Bind to loopback only: the app is unreachable except through the tunnel.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")))
