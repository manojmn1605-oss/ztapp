#!/usr/bin/env bash
# Run on the Ubuntu VM from inside ~/ztapp:  bash setup.sh <TEAM_NAME> <APP_AUD_TAG>
set -euo pipefail
TEAM="${1:?team name required}"; AUD="${2:?AUD tag required}"

sudo apt-get update -y && sudo apt-get install -y python3-venv python3-pip
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

printf 'CF_TEAM_NAME=%s\nCF_ACCESS_AUD=%s\n' "$TEAM" "$AUD" | sudo tee /etc/ztapp.env >/dev/null
sudo chmod 600 /etc/ztapp.env

sudo cp ztapp.service /etc/systemd/system/ztapp.service
sudo systemctl daemon-reload
sudo systemctl enable --now ztapp
systemctl --no-pager status ztapp | head -n 5
echo "App listening on 127.0.0.1:5000. Now point your Cloudflare Tunnel hostname at http://localhost:5000"
